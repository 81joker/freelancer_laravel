<div {{ $attributes->merge(['class' => 'card-header']) }}>
    {{ $slot }}
</div>
