<div {{ $attributes->merge(['class' => 'datagrid']) }}>
    {{ $slot }}
</div>
