@props(['id'])
<script type="text/x-custom-template" id="{{ $id }}">
    {{ $slot }}
</script>
