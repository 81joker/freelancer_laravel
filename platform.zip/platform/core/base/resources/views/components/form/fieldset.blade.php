<fieldset {{ $attributes->merge(['class' => 'form-fieldset']) }}>
    {{ $slot }}
</fieldset>
