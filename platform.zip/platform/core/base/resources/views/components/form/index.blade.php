{!! Form::open($attributes->getAttributes()) !!}
    {{ $slot }}
{!! Form::close() !!}
