<x-core::form.text-input {{ $attributes->merge(['data-bb-color-picker' => '']) }}  />
