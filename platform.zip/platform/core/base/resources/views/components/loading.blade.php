<div {{ $attributes->merge(['class' => 'loading-spinner']) }}></div>
